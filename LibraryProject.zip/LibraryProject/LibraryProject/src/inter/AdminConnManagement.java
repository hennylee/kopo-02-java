package inter;

public interface AdminConnManagement {
	
	/**
	 *  로그인
	 * @return
	 */
	public boolean AdminLogIn();	
	
	/**
	 *  로그아웃
	 * @return
	 */
	public boolean AdminLogOut(); 
	
}
