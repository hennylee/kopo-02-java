package inter;

public interface MemberConnManagement {
	
	/**
	 *  로그인
	 * @return
	 */
	public boolean MemberLogIn();	
	
	/**
	 *  로그아웃
	 * @return
	 */
	public boolean MemberLogOut(); 
	
	
}
